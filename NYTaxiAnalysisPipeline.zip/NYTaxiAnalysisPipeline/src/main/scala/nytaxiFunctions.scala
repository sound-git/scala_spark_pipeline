import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.{DoubleType, IntegerType, StringType, StructType, TimestampType}

object nytaxiFunctions {
  /**
   *  This method is used to create SparkSession object
   */
  def start_spark = {
    val spark = SparkSession.builder()
      .config("spark.driver.memory", "4g")
      .appName("NYTaxiIngestAndRefine")
      .master("local[*]")
      .getOrCreate()
    spark
  }

  /**
   *  This method is used to create SparkContext object
   */
  def start_sc(spark: SparkSession)={
    val sc = spark.sparkContext
    sc
  }

  /**
   *  This method is used to read the schema of the source file.
   *  schema_arg is the input required which contains the Column name and Column data type in the following format
   *  "col1 col1DataType, col2 col2DataType,..."
   *  Example: nytaxiSchema = "vendor_id IntegerType,tpep_pickup_datetime TimestampType,...."
   *  For the above example this method creates a StructType
   *  StructType(Array(
   *    StructField("col1",col1DataType,true),
   *    StructField("col2",col2DataType,true)
   *  ))
   */
  def read_schema(schema_arg: String) = {
    val split_values = schema_arg.split(",").toList
    var sch : StructType = new StructType

    val d_types = Map(
      "StringType" -> StringType,
      "IntegerType" -> IntegerType,
      "DoubleType" -> DoubleType,
      "TimestampType" -> TimestampType
    )

    for(i <- split_values){
      val column_val = i.split(" ").toList
      sch = sch.add(column_val(0), d_types(column_val(1)), true)
    }
    sch
  }

  /**
   *  This method is used to read a parquet file with below conditions
   *  1.Schema is explicitly mentioned
   *  2.Header is true
   *  3.File location is needed
   *  4.returns a DataFrame
   */
  def read_parquet_withschema(fileLocation: String, fileSchema: StructType, spark: SparkSession)={
    val df = spark.read
      .schema(fileSchema)
      .option("header","true")
      .parquet(fileLocation)
    df
  }

  /**
   *  This method is used to read a CSV file with below conditions
   *  1.Header is true
   *  2.InferSchema is true
   *  3.returns a DataFrame
   */
  def read_csv_inferschema(fileLocation: String, spark: SparkSession)={
    val df = spark.read
      .option("header","true")
      .option("inferSchema","true")
      .csv(fileLocation)
    df
  }

  /**
   *  This method is used to write a CSV file with below conditions
   *  It takes a Dataframe as input and a fileLocation to which it has to be written as arguments
   *  1.Header is true
   *  2.Output format is CSV file
   *  3.The file will be written to the output fileLocation mentioned
   *  4.If the job is re-run, the file will be overwritten
   */
  def write_csv_output(df: DataFrame, fileLocation: String, spark: SparkSession)={
     df.coalesce(1)
       .write
       .format("csv")
       .option("header","true")
       .option("delimiter",",")
       .mode("overwrite")
       .save(fileLocation)
  }

}