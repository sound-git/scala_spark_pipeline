import com.typesafe.config.{Config, ConfigFactory}
import nytaxiFunctions.{read_csv_inferschema, read_parquet_withschema, read_schema, start_sc, start_spark, write_csv_output}
import org.apache.spark.sql.functions._
import projectFunctions._

object NYTaxiIngestAndRefine {
  def main(args: Array[String]): Unit = {
    /**
     *  Create the SparkSession and SparkContext objects
     */
    val spark = start_spark
    val sc = start_sc(spark)
    import spark.implicits._

    /**
     *  Read input and output locations from "application.conf" file
     *  Also read the Source (ny_taxi) file's schema
     */
    // Reading parameters from Config file
    val nyconfig: Config = ConfigFactory.load("application.conf")
    val inputLocation = nyconfig.getString("paths.inputLocation")
    val nyTaxiSchemaFromConfig = nyconfig.getString("schema.nytaxiSchema")
    val outputLocation = nyconfig.getString("paths.outputLocation")
    // Reading Schema of ny_taxi file
    val nyTaxiSchema = read_schema(nyTaxiSchemaFromConfig)

    /**
     *  Determine the input and output files names for further use
     *  Input Files: nytaxifile, nytaxirtbffile, nyzonefile
     *  Output Files: insight1Out, insight2Out, insight3Out, insight4Out, insight5Out, insight6Out, insight7Out
     */
    val nytaxifile = inputLocation + "ny_taxi"
    val nytaxirtbffile = inputLocation + "ny_taxi_rtbf"
    val nyzonefile = inputLocation + "ny_zones"
    val insight1Out = outputLocation + "average_total_fare_trips"
    val insight2Out = outputLocation + "number_pickups_zone"
    val insight3Out = outputLocation + "number_pickups_borough"
    val insight4Out = outputLocation + "number_dropoffs_zone"
    val insight5Out = outputLocation + "number_dropoffs_borough"
    val insight6Out = outputLocation + "top_dropoff_zone"
    val insight7Out = outputLocation + "average_trips_per_hour"

    /**
     *  Read the input files and store the data in dataframes for future use
     *  nyTaxiDF: contains data of source file ny_taxi
     *  nyTaxiRtbfDF: contains data of source file ny_taxi_rtbf
     *  nyZonesDF: contains data of source file ny_zones
     */
    val nyTaxiDF = read_parquet_withschema(nytaxifile, nyTaxiSchema, spark)
    val nyTaxiRtbfDF = read_csv_inferschema(nytaxirtbffile, spark)
    val nyZonesDF = read_csv_inferschema(nyzonefile, spark)

    /**
     *  Perform Transformations
     *  1.filter the ny_taxi data between the dates 2015-01-15 to 2015-02-15 using the tpep_pickup_datetime column
     *  2.Filter right to be forgotten taxi_ids. Remove all rows that have a taxi_id that is in the ny_taxi_rtbf list.
     *  3.geocode each pickup and dropoff location with zone and borough with ny_taxi_zones and rtbf & dates filtered ny_taxi data
     */
    val nyTaxiFilteredDF = nyTaxiFilterDates(nyTaxiDF)
    val nyTaxiExceptRtbfDF = nyTaxiExceptRtbf(nyTaxiFilteredDF, nyTaxiRtbfDF)
    val geocodeTaxiZonesDF = geocodeTaxiZones(nyZonesDF, nyTaxiExceptRtbfDF, spark)

    //
    /**
     *  Calculate and save insights as csv files in Output Location
     *  Insight 1: Calculate the average total fare for each trip_distance (trip distance rounded to 0 decimal places) and the number of trips. Order the output by trip_distance.
     *  Rerun the Insight 1 by filtering rows if any of the columns: pickup_zone, pickup_borough, dropoff_zone and dropoff_borough are null.
     *  Insight 2: Total number of pickups in each zone.
     *  Insight 3: Total number of pickups in each borough.
     *  Insight 4: Total number of dropoffs, average total cost and average distance in each zone.
     *  Insight 5: Total number of dropoffs, average total cost and average distance in each borough.
     *  Insight 6: For each pickup zone calculate the top 5 dropoff zones ranked by number of trips.
     *  Insight 7: Calculate the number of trips for each date -> pickup hour, (using tpep_pickup_datetime), then calculate the average number of trips by hour of day.
     */
    avgTotalFareTripInsight(geocodeTaxiZonesDF, insight1Out, spark)

    val TaxiFilteredDF = geocodeTaxiZonesDF.filter(col("pickup_zone").isNotNull and col("pickup_borough").isNotNull
      and col("pickup_zone").isNotNull and col("pickup_borough").isNotNull)

    avgTotalFareTripInsight(TaxiFilteredDF, insight1Out, spark)

    totalPickupInsight(geocodeTaxiZonesDF, "pickup_zone", "zone", insight2Out, spark)

    totalPickupInsight(geocodeTaxiZonesDF, "pickup_borough", "borough", insight3Out, spark)

    totalDropoffInsight(geocodeTaxiZonesDF,"dropoff_zone", "zone", "total_amount", "average_total_fare", "trip_distance", "average_trip_distance", insight4Out, spark)

    totalDropoffInsight(geocodeTaxiZonesDF,"dropoff_borough", "borough", "total_amount", "average_total_fare", "trip_distance", "average_trip_distance", insight5Out, spark)

    topDropoffZoneIngisht(geocodeTaxiZonesDF, insight6Out, spark)

    averageTripsInsight(geocodeTaxiZonesDF, insight7Out, spark)

  }

}
