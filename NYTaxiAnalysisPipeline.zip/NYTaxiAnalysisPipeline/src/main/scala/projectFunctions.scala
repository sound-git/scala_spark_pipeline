import nytaxiFunctions.write_csv_output
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{asc, avg, col, count, expr, hour, rank, round, row_number}

object projectFunctions {

  /**
   *  This method is used to filter ny_taxi data between the dates 2015-01-15 to 2015-02-15
   *  using the tpep_pickup_datetime column.
   */
  def nyTaxiFilterDates(df:DataFrame)= {
    val filterDF = df.filter(col("tpep_pickup_datetime")>="2015-01-15"
      and col("tpep_pickup_datetime")<="2015-02-15")
    filterDF
  }

  /**
   *  This method is used to Filter right to be forgotten taxi_ids.
   *  Remove all rows that have a taxi_id that is in the ny_taxi_rtbf list.
   */
  def nyTaxiExceptRtbf(df1:DataFrame, df2:DataFrame)={
    val exceptRtbfDF = df1.join(df2,df1("taxi_id")===df2("taxi_id"),"leftsemi")
    val exceptRtbfEnrichedDF = exceptRtbfDF.withColumn("pickup_h3_index", expr("conv(pickup_h3_index, 16, 10)"))
      .withColumn("dropoff_h3_index", expr("conv(dropoff_h3_index, 16, 10)"))
    exceptRtbfEnrichedDF
  }

  /**
   *  With this method, four new columns are created : pickup_zone, pickup_borough, dropoff_zone and dropoff_borough
   *  Using the geocoding data (ny_taxi_zones) and the appropriate index column in the ny_taxi data,
   *  geocode each pickup location with zone and borough.
   *  After above step, geocode each dropoff location with zone and borough
   */
  def geocodeTaxiZones(df1:DataFrame, df2:DataFrame, spark:SparkSession)={
    df1.createOrReplaceTempView("nytaxizone")
    df2.createOrReplaceTempView("nytaxi")
    val geocodePickDF = spark.sql("SELECT t1.* "+
      ",CASE WHEN t2.h3_index is not null THEN t2.zone END as pickup_zone " +
      ",CASE WHEN t2.h3_index is not null THEN t2.borough END as pickup_borough " +
      "From nytaxi t1 " +
      "Left Join nytaxizone t2 " +
      "ON t1.pickup_h3_index == t2.h3_index " +
      "Where t2.h3_index is not null"
    )
    geocodePickDF.createOrReplaceTempView("geopick")
    val geocodeDropDF = spark.sql("SELECT t1.* "+
      ",CASE WHEN t2.h3_index is not null THEN t2.zone END as dropoff_zone" +
      ",CASE WHEN t2.h3_index is not null THEN t2.borough END as dropoff_borough " +
      "From geopick t1 " +
      "Left Join nytaxizone t2 " +
      "ON t1.dropoff_h3_index == t2.h3_index " +
      "Where t2.h3_index is not null"
    )
    geocodeDropDF
  }

  /**
   *  This method is used to create an insight on average total fare for each trip_distance.
   *  Round off trip_distance to 0 decimal places.
   *  Order the output by trip_distance.
   *  The resulting output will have 3 columns: trip_distance, average_total_fare and number_of_trips.
   *  Output is written to the output location (outputloc) given as argument.
   */
  def avgTotalFareTripInsight(df1: DataFrame, outputloc: String, spark: SparkSession)={
    val outputDF = df1.groupBy(round(col("trip_distance")).cast("int"))
      .agg(avg(col("total_amount")).alias("average_total_fare"),
        count(col("trip_distance")).alias("number_of_trips")
      )
      .withColumnRenamed("CAST(round(trip_distance, 0) AS INT)", "trip_distance")
      .where(col("trip_distance")>=0)
      .orderBy(asc("trip_distance"))
    outputDF.createOrReplaceTempView("avgtotalfareTable")
    val max_trip_distance = spark.sql("Select MAX(trip_distance) from avgtotalfareTable")
    write_csv_output(outputDF, outputloc, spark)
  }

  /**
   *  This method is used to create an insight on the number of pickups for each Zone and Borough.
   *  The arguments takes the following values:
   *  df1 - DataFrame on which computations to take place
   *  groupedcolname - represents pickup/ dropoff zone or borough for which we need to compute number of pickups
   *  displaycolname - represents the alias name to be displayed in output for the groupedColumn (zone/ borough)
   *  The resulting output will have 2 columns: zone and number_of_pickups/ borough and number_of_pickups.
   *  Output is written to the output location (outputloc) given as argument.
   */
  def totalPickupInsight(df1: DataFrame, groupedcolname: String, displaycolname: String, outputloc: String, spark: SparkSession)={
    val outputDF = df1.groupBy(col(groupedcolname))
      .agg(
        count("*").alias("number_of_pickups")
      )
      .withColumnRenamed(groupedcolname, displaycolname)
    write_csv_output(outputDF, outputloc, spark)
  }

  /**
   *  This method is used to create an insight on the number of pickups for each Zone and Borough.
   *  The arguments takes the following values:
   *  df1 - DataFrame on which computations to take place
   *  groupedcolname - represents pickup/ dropoff zone or borough for which we need to compute number of pickups
   *  displaycolname - represents the alias name to be displayed in output for the groupedColumn (zone/ borough)
   *  The resulting output will have 2 columns: zone and number_of_pickups/ borough and number_of_pickups.
   *  Output is written to the output location (outputloc) given as argument.
   */
  def totalDropoffInsight(df1: DataFrame, groupedcolname: String, displaygroupcolname: String, aggname1: String, displayaggname1: String, aggname2: String, displayaggname2: String, outputloc: String, spark: SparkSession)={
    val outputDF = df1.groupBy(col(groupedcolname))
      .agg(
        count("*").alias("number_of_dropoffs"),
        round(avg(col(aggname1)),1).alias(displayaggname1),
        round(avg(col(aggname2)),1).alias(displayaggname2)
      )
      .withColumnRenamed(groupedcolname, displaygroupcolname)
    write_csv_output(outputDF, outputloc, spark)
  }

  /**
   *  This method is used to create an insight on the top 5 dropoff zones for
   *  each pickup zones ranked by number of trips.
   *  Output is written to the output location (outputloc) given as argument.
   */
  def topDropoffZoneIngisht(df1: DataFrame, outputloc: String, spark: SparkSession)={
    val windowSpec1  = Window.partitionBy(col("pickup_zone"))
    val windowSpec2 = Window.partitionBy(col("pickup_zone")).orderBy(col("pickup_zone") asc)
    val rankDF = df1.groupBy(col("pickup_zone"),col("dropoff_zone"))
      .agg(count("*").over(windowSpec1).alias("number_of_dropoffs")).alias("number_of_dropoffs")
      .withColumn("rank",row_number().over(windowSpec2))

    val outputDF = rankDF.filter(col("rank")<=5)
    write_csv_output(outputDF, outputloc, spark)
  }

  /**
   *  This method is used to create an insight to see the number of trips for each date
   *  Calculate the average number of trips by hour of day.
   *  Output is written to the output location (outputloc) given as argument.
   */
  def averageTripsInsight(df1: DataFrame, outputloc: String, spark: SparkSession)={
    val tripsDF = df1.groupBy(hour(col("tpep_pickup_datetime")))
      .agg(count("*").alias("average_trips"))
      .withColumnRenamed("hour(tpep_pickup_datetime)","hour_of_day")
      .orderBy(col("hour_of_day").asc)
    val outputDF = tripsDF.groupBy(col("hour_of_day"))
      .avg("average_trips").alias("average_trips")
    write_csv_output(outputDF, outputloc, spark)
  }
}